#pragma once
#include<windows.h>
VOID HookLogMsgInfo();
VOID UnHookLogMsgInfo();