from Python import sever

#code = '啊，我死了'
code = input('----->')
sever.sever(code)
