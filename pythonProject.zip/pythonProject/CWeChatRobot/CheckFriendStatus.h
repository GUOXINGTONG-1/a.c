#pragma once
#include<windows.h>
BOOL CheckFriendStatusInit();
DWORD CheckFriendStatus(wchar_t* wxid);
BOOL CheckFriendStatusFinish();