#pragma once
#include<windows.h>

SAFEARRAY* ExecuteSQL(DWORD DbHandle, BSTR sql);