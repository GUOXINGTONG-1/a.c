#pragma once
#include<windows.h>

int SendImage(wchar_t* wxid, wchar_t* imagepath);