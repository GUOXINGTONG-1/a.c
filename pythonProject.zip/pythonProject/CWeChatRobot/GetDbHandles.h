#pragma once
#include <windows.h>
SAFEARRAY* GetDbHandles();