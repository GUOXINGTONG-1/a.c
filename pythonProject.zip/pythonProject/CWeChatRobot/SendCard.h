#pragma once
#include<windows.h>
BOOL SendCard(wchar_t* receiver, wchar_t* sharedwxid, wchar_t* nickname);