#pragma once
#include<windows.h>
BOOL BackupSQLiteDB(DWORD DbHandle, BSTR savepath);