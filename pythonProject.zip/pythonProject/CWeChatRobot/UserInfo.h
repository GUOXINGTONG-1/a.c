#pragma once
#include <windows.h>
#include <iostream>
using namespace std;
std::wstring GetWxUserInfo(wchar_t* wxid);