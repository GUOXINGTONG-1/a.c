#pragma once
#include<windows.h>
bool Injert(DWORD dwPid, wchar_t* workPath);
BOOL RemoveDll(DWORD dwId);