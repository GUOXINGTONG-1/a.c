#pragma once
#include<windows.h>

int SendFile(wchar_t* wxid, wchar_t* filepath);