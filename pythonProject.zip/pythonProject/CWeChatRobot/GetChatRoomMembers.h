#pragma once
#include<windows.h>
SAFEARRAY* GetChatRoomMembers(wchar_t* chatroomid);