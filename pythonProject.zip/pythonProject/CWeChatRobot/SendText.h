#pragma once
#include<windows.h>

int SendText(wchar_t* wxid, wchar_t* wxmsg);
