#pragma once
#include<windows.h>
#include<iostream>
using namespace std;
SAFEARRAY* GetFriendList();
std::wstring GetFriendListString();